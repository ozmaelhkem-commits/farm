مزرعتي - مشروع أندرويد (WebView) بيشغّل اللعبة من app/src/main/assets/index.html
البناء: gradle assembleDebug  ->  app/build/outputs/apk/debug/app-debug.apk
